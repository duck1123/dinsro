chrome.devtools.panels.create("Fulcro Inspect",
  "",
  "inspect-panel.html",
  function (panel) {
    console.log("panel initialized", panel);
  });
